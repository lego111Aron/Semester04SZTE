package hu.alkfejl.servlet;

public enum CookieNames {

    FELPANZIO("felpanzio");

    public final String name;
    CookieNames(String name) {
        this.name = name;
    }
}
