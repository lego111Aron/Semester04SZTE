


curl -X POST -H "Content-Type: application/json" -d "{\"cim\": \"Vihar\",\"stilus\": \"Rock\",\"eloado\": \"Kowalsky meg a Vega\",\"hossz\": 245}"